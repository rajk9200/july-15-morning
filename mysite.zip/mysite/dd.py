
data =[]
class Posts:

    def __init__(self):
        self.title=""
        self.desc=""


    def add_post(self):
        data.append(self)

while(True):
    title=input('enter title=')
    desc=input('enter desc=')
    p =Posts()
    p.title =title
    p.desc =desc
    p.add_post()
    ui=input('bahar aana ho to 0 press karo :')
    if ui=='0':
        break



print(data)
for v in data:
    print(v.title)
    print(v.desc)
    print(v)

